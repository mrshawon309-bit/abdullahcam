export default async (request) => {
  if (request.method !== "POST") {
    return json({ error: "Method not allowed." }, 405);
  }

  try {
    const body = await request.json();
    const url = String(body?.url || "").trim();

    if (!isHttpUrl(url)) {
      return json({ error: "A valid public HTTP/HTTPS URL is required." }, 400);
    }

    const parsed = new URL(url);
    const domain = parsed.hostname.replace(/^www\./, "");

    // API-ready placeholder:
    // Add your authorized media-processing provider here.
    // Keep provider keys in Netlify environment variables.
    return json({
      success: true,
      demo: true,
      title: "Media ready for processing",
      domain
    });
  } catch {
    return json({ error: "Invalid request." }, 400);
  }
};

function isHttpUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {"Content-Type": "application/json"}
  });
}
