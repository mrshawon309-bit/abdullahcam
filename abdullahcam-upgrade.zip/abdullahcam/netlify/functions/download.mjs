export default async (request) => {
  if (request.method !== "POST") {
    return json({ error: "Method not allowed." }, 405);
  }

  try {
    const body = await request.json();
    const url = String(body?.url || "").trim();
    const format = String(body?.format || "mp4").toLowerCase();

    if (!isHttpUrl(url)) {
      return json({ error: "A valid public HTTP/HTTPS URL is required." }, 400);
    }

    if (!["mp4", "mp3"].includes(format)) {
      return json({ error: "Unsupported format." }, 400);
    }

    // API-ready placeholder:
    // Connect an authorized media-processing provider here.
    // Never expose provider API keys in the browser.
    return json({
      success: true,
      demo: true,
      message: "Backend is connected. Add your authorized media-processing provider to enable real downloads."
    });
  } catch {
    return json({ error: "Invalid request." }, 400);
  }
};

function isHttpUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {"Content-Type": "application/json"}
  });
}
